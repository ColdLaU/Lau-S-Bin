var amount;
var gps;
var upgrade_01;
var upgrade_02;
var upgrade_03;
var upgrade_04;
var upgrade_05;
var upgrade_06;
var upgrade_07;
var upgrade_08;
var upgrade_09;
var upgrade_10;
var worker;
var modifier_01;
var modifier_02;
var modifier_03;
var modifier_04;
var modifier_05;
var modifier_06;
var modifier_07;
var modifier_08;
var modifier_09;
var modifier_10;

function mining() {
  document.getElementById("amount").innerHTML = "<br>gold<br>Gps ";
  amount = amount + 1;
  updateAmount();
}

function updateAmount() {
  document.getElementById("amount").innerHTML = amount + "<br>gold<br>Gps " + gps;
}

function updateTotal() {
  gps = modifier_01 + modifier_02 + modifier_03 + modifier_04 + modifier_05 + modifier_06 + modifier_07 + modifier_08 + modifier_09 + modifier_10;
}

function initGame() {
  amount = 0;
  gps = 0;
  upgrade_01 = 0;
  upgrade_02 = 0;
  upgrade_03 = 0;
  upgrade_04 = 0;
  upgrade_05 = 0;
  upgrade_06 = 0;
  upgrade_07 = 0;
  upgrade_08 = 0;
  upgrade_09 = 0;
  upgrade_10 = 0;
  modifier_01 = 0;
  modifier_02 = 0;
  modifier_03 = 0;
  modifier_04 = 0;
  modifier_05 = 0;
  modifier_06 = 0;
  modifier_07 = 0;
  modifier_08 = 0;
  modifier_09 = 0;
  modifier_10 = 0;
  createWorker();
}

function tick() {
  amount += gps;
  updateAmount();
}

function createWorker() {
  if (worker == undefined) {
    worker = new Worker("scripts/worker.js");
  }
  worker.onmessage = function(event) {
            tick();
          };
}

function stopWorker() {

}

function buyUpgrade_01() {
  if (amount >= 10) {
    modifier_01++;
    amount = amount - 10;
    upgrade_01++; // upgrade = upgrade + 1;
    document.getElementById("quantity01").innerHTML = upgrade_01;
    updateTotal();
    updateAmount();
  }
}
function buyUpgrade_02() {
  if (amount >= 150) {
    modifier_02 += 10;
    amount = amount - 150;
    upgrade_02++; // upgrade = upgrade + 1;
    document.getElementById("quantity02").innerHTML = upgrade_02;
    updateTotal();
    updateAmount();
  }
}
function buyUpgrade_03() {
  if (amount >= 1000) {
    modifier_03 += 100;
    amount = amount - 1000;
    upgrade_03++; // upgrade = upgrade + 1;
    document.getElementById("quantity03").innerHTML = upgrade_03;
    updateTotal();
    updateAmount();
  }
}
function buyUpgrade_04() {
  if (amount >= 5500) {
    modifier_04 += 500;
    amount = amount - 5500;
    upgrade_04++; // upgrade = upgrade + 1;
    document.getElementById("quantity04").innerHTML = upgrade_04;
    updateTotal();
    updateAmount();
  }
}
function buyUpgrade_05() {
  if (amount >= 30000) {
    modifier_05 += 3000;
    amount = amount - 30000;
    upgrade_05++; // upgrade = upgrade + 1;
    document.getElementById("quantity05").innerHTML = upgrade_05;
    updateTotal();
    updateAmount();
  }
}
function buyUpgrade_06() {
  if (amount >= 100000) {
    modifier_06 += 10000;
    amount = amount - 100000;
    upgrade_06++; // upgrade = upgrade + 1;
    document.getElementById("quantity06").innerHTML = upgrade_06;
    updateTotal();
    updateAmount();
  }
}
function buyUpgrade_07() {
  if (amount >= 1000000) {
    modifier_07++;
    amount = amount - 1000000;
    upgrade_07++; // upgrade = upgrade + 1;
    document.getElementById("quantity07").innerHTML = upgrade_07;
    updateTotal();
    updateAmount();
  }
}
function buyUpgrade_08() {
  if (amount >= 10000000) {
    modifier_08++;
    amount = amount - 10000000;
    upgrade_08++; // upgrade = upgrade + 1;
    document.getElementById("quantity08").innerHTML = upgrade_08;
    updateTotal();
    updateAmount();
  }
}
function buyUpgrade_09() {
  if (amount >= 150000000) {
    modifier_09++;
    amount = amount - 150000000;
    upgrade_09++; // upgrade = upgrade + 1;
    document.getElementById("quantity09").innerHTML = upgrade_09;
    updateTotal();
    updateAmount();
  }
}
function buyUpgrade_10() {
  if (amount >= 1000000000) {
    modifier_10++;
    amount = amount - 1000000000;
    upgrade_10++; // upgrade = upgrade + 1;
    document.getElementById("quantity10").innerHTML = upgrade_10;
    updateTotal();
    updateAmount();
  }
}
